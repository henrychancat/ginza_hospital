<?php get_header(); ?>
    <div class="flexslider pc">
        <ul class="slides">
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/home.png"/>
            </li>
        </ul>
    </div>
    <div class="flexslider sp">
        <ul class="slides">
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/sp/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/sp/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/sp/home.png"/>
            </li>
            <li>
                <img src="<?php echo get_template_directory_uri(); ?>/images/sp/home.png"/>
            </li>
        </ul>
    </div>
    <div class="home-main-title-container">
        <p class="home-main-title">
            キャッチコピーが入ります
        </p>
    </div>
    <div class="scroll-text-container">
        <p class="scroll-text">
            SCROLL
        </p>
    </div>
    <div class="center-line-container">
        <div class="line"></div>
    </div>
    <div class="doctor-introduction-section home-section sp-none">
        <div class="doctor-introduction">
            <div class="home-section-title">
                <span class="english">DOCTOR</span>
                <span class="japanese">院長紹介</span>
            </div>
            <div class="doctor-introduction-title-container">
                <p class="doctor-introduction-title">
                    こちらにリードコピーが入ります
                </p>
            </div>
            <div class="doctor-introduction-text-container">
                <p class="doctor-introduction-text">
                    テキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入ります(250文字程度)
                </p>
            </div>
            <div ><a href="#" class="text-banner">院長紹介はこちら <i class="fas fa-chevron-right"></i></a></div>
        </div>
        <div class="doctor-introduction">
            <div class="doctor-info-image-container">
                <img src="<?php echo get_template_directory_uri(); ?>/images/doctor.png">
                <div class="doctor-info-container">
                    <p class="doctor-info-clinic">
                        銀座たるみクリニック
                    </p>
                    <p class="doctor-info-post">院長</p>
                    <p class="doctor-info-name">上野美律</p>
                </div>
            </div>
        </div>
    </div>
    <div class="doctor-introduction-section home-section sp">
        <div class="doctor-introduction">
            <div class="home-section-title">
                <span class="english">DOCTOR</span>
                <span class="japanese">院長紹介</span>
            </div>
            <div class="doctor-info-image-container">
                <img src="<?php echo get_template_directory_uri(); ?>/images/doctor.png">
                <div class="doctor-info-container">
                    <p class="doctor-info-clinic">
                        銀座たるみクリニック
                    </p>
                    <p class="doctor-info-post">院長</p>
                    <p class="doctor-info-name">上野美律</p>
                </div>
            </div>
            <div class="doctor-introduction-title-container">
                <p class="doctor-introduction-title">
                    こちらにリードコピーが入ります
                </p>
            </div>
            <div class="doctor-introduction-text-container">
                <p class="doctor-introduction-text">
                    テキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入ります(250文字程度)
                </p>
            </div>
            <div ><a href="#" class="text-banner">院長紹介はこちら <i class="fas fa-chevron-right"></i></a></div>
        </div>
    </div>
  <div class="feature-section home-section">
    <div class="feature-section-title">
      <span class="japanese">当院の特徴</span>
      <span class="english">FEATURE</span>
    </div>
      <div class="feature-section-content">
    <div><img src="<?php echo get_template_directory_uri(); ?>/images/feature1.png"></div>
      <div class="feature-content-right-container">
          <p class="feature-section-subtitle">01   <span class="line-horizontal"></span>    FEATURE</p>
          <p class="feature-title">こちらにリードコピーが入ります</p>
          <p class="feature-text">テキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入ります(100文字程度)</p>
      </div>
      </div>
      <div class="feature-section-content">
      <div><img src="<?php echo get_template_directory_uri(); ?>/images/feature2.png" class="feature-image-right"></div>
          <div class="feature-content-left-container">
              <p class="feature-section-subtitle">02   <span class="line-horizontal"></span>    FEATURE</p>
              <p class="feature-title">こちらにリードコピーが入ります</p>
              <p class="feature-text">テキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入りますテキストが入ります(100文字程度)</p>
          </div>
      </div>
  </div>
    <div class="treatment-section home-section">
        <div class="home-section-title">
            <span class="english">TREATMENT</span>
            <span class="japanese">施術案内</span>
        </div>
        <div class="treatment-container">
            <div class="treatment-container-segment-left"><img src="<?php echo get_template_directory_uri(); ?>/images/treatment1.png"></div>
            <div class="treatment-container-segment">
                <ul class="treatment-list">
                <li><a href="#" class="text-banner"><span class="circle"></span>ヒアルロン酸<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>ボツリヌストキシン注入<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>Q-Plus(HIFU)　顔<i class="fas fa-chevron-right"></i></a></li>
                <li><a href="#" class="text-banner"><span class="circle"></span>Q-Plus(HIFU)　2重顎<i class="fas fa-chevron-right"></i></a></li>
                <li><a href="#" class="text-banner"><span class="circle"></span>ショッピングスレッド<i class="fas fa-chevron-right"></i></a></li>
                </ul>
            </div>
            <div class="treatment-container-segment-left">
                <ul class="treatment-list">
                    <li><a href="#" class="text-banner"><span class="circle"></span>スレッドリフト<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>水光注射<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>ダーマペン<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>マッサージピール<i class="fas fa-chevron-right"></i></a></li>
                    <li><a href="#" class="text-banner"><span class="circle"></span>BNSL neo(脂肪溶解注射)<i class="fas fa-chevron-right"></i></a></li>
                </ul>
            </div>
            <div class="treatment-container-segment image-right pc"><img src="<?php echo get_template_directory_uri(); ?>/images/treatment2.png"></div>
        </div>
    </div>

    <div class="clinic-image-container">
        <img src="<?php echo get_template_directory_uri(); ?>/images/clinic-view-1.png" class="home-image-1" alt="bsan">
        <img src="<?php echo get_template_directory_uri(); ?>/images/clinic-view-2.png" class="home-image" alt="bsan">
        <p class="home-clinic-text">キャッチコピーが入ります</p>
    </div>
    <div class="access-section home-section">
        <div class="home-section-title">
            <span class="english">CLINIC</span>
            <span class="japanese">医院紹介</span>
        </div>
        <div class="home-section-flex">
            <table class="time-table">
                <tbody>
                <tr class="title-row">
                    <td class="time-table-content-cell">診療時間</td>
                    <td class="time-table-content-cell">
                        <span class="day">月</span>
                        <span class="day">火</span>
                        <span class="day">水</span>
                        <span class="day">木</span>
                        <span class="day">金</span>
                        <span class="day">土</span>
                        <span class="day">日</span>
                        <span class="day">祝</span>
                    </td>
                </tr>
                <tr class="content-row">
                    <td class="time-table-content-cell">00:00-00:00</td>
                    <td class="time-table-content-cell">
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                    </td>
                </tr>
                <tr class="content-row">
                    <td class="time-table-content-cell">00:00-00:00</td>
                    <td class="time-table-content-cell">
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                    </td>
                </tr>
                </tbody>
            </table>
            <div class="clinic-info">
                <p class="clinic-info-title">銀座たるみクリニック</p>
                <p class="clinic-info-text">〒104-0061 東京都中央区銀座 7-13-1</p>
                <p class="clinic-info-text">東京メトロ「●●駅」より徒歩●●分</p>
                <p class="clinic-info-text">休診日: ●曜日/●曜日</p>
                <p class="clinic-info-text">※診療時間の注意事項が入ります診療時間の注意事項が入ります診療時間の注意事項が入ります診療時間の注意事項が入ります</p>
                <a href="#" class="text-banner fit-content">医院紹介はこちら<i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
    </div>
    <div>
        <iframe frameborder="0" style="border:0; width: 100%; height: 50vh"
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12955.795134271655!2d139.7135962!3d35.7274781!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7865dcff68fe5e37!2sB-LINE%20CLINIC!5e0!3m2!1sja!2sjp!4v1574618044417!5m2!1sja!2sjp"
                allowfullscreen>
        </iframe>
    </div>
<?php get_footer(); ?>
