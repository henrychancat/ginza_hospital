<?php get_header(); ?>
    <div class="hero">
    <img src="<?php echo get_template_directory_uri(); ?>/images/top.png" alt="top" class="top_pc" />
    <h2 class="page-title">お問い合わせ</h2>
    <img src="<?php echo get_template_directory_uri(); ?>/images/sp/top.png" alt="top" class="top_sp" />
  </div>
  <div class="section breadcrumb-section">
    <ul class="breadcrumb">
      <li><a href="/">TOP</a></li>
      <li>bread</li>
    </ul>
  </div>
  <div class="section">
    <h3 class="page-main-title">お問い合わせ</h3>
    <div class="line-horizontal"></div>
    <div>
      <div class="contact-section contact">
        <form action="" class="" method="post" accept-charset="UTF-8">
          <div class="contact-content">
            <p class="contact-content-title">テキストフィールド</p>
            <div class="contact-content-body">
              <input type="text" class="text-input" placeholder="テキストフィールド">
            </div>
          </div>
          <div class="contact-content">
            <p class="contact-content-title">ドロップダウン</p>
            <div class="contact-content-body">
              <select class="text-input">
                <option value="">選択してください</option>
                <option value="1" >1</option>
                <option value="2" >2</option>
                <option value="3" >3</option>
              </select>
            </div>
          </div>
          <div class="contact-content">
            <p class="contact-content-title">チェックボックス</p>
            <div class="contact-content-body contact-content-radio">
              <div>
                <input class="text-input checkbox-input" type="checkbox" value="1" id="select01"><label for="select01">select01</label>
              </div>
              <div style="padding-top: 16px">
                <input class="text-input checkbox-input" type="checkbox" value="2" id="select02"><label for="select02">select02</label>
              </div>
              <div style="padding-top: 16px">
                <input class="text-input checkbox-input" type="checkbox" value="3" id="select03"><label for="select03">select03</label>
              </div>
            </div>
          </div>
          <div class="contact-content">
            <p class="contact-content-title">テキストエリア</p>
            <div class="contact-content-body">
              <textarea type="text" class="textarea-input" placeholder="テキストを入力してください"></textarea>
            </div>
          </div>
          <div class="contact-content">
            <div type="submit" class="text-banner">送信内容を確定する<i class="fas fa-chevron-right"></i></div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php get_footer(); ?>
