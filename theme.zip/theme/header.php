<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>銀座たるみクリニック</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css" type="text/css" media="all" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.flexslider-min.js"></script>
    <script async src="<?php echo get_template_directory_uri(); ?>/js/index.js"></script>
    <script src="https://use.typekit.net/fya1swr.js"></script>
    <script>
        try {
            Typekit.load({async: true});
        } catch (e) {
        }
    </script>
    <?php wp_head();?>
</head>
<body>
<div class="wrapper">
    <header>
        <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="logo" class="logo"/>
        <nav id="nav" class="">
            <ul class="dropdown">
                <li class="li-intro"><a href="#" class="dropbtn">医院紹介</a>
                    <div id="dropdown-content" class="dropdown-content">
                        <a href="#" class="sub-menu-link">Link 1</a>
                        <a href="#" class="sub-menu-link">Link 2</a>
                        <a href="#" class="sub-menu-link">Link 3</a>
                    </div>
                </li>
                <li><a href="#">院長紹介</a></li>
                <li><a href="#">診療案内</a></li>
                <li><a href="#">ブログ</a></li>
                <li><a href="/contact" class="contact-form-button">お問い合わせ</a></li>
            </ul>

        </nav>
        <div id="nav-toggle">
            <div>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <div id="gloval-nav">
            <nav>
                <ul id="nav-links">
                    <li><a href="#">医院紹介？</a></li>
                    <li><a href="#">院長紹介</a></li>
                    <li><a href="#">診療案内</a></li>
                    <li><a href="#">ブログ</a></li>
                    <li><a href="#">お問い合わせ</a></li>
                </ul>
            </nav>
        </div>

    </header>
    <main>