<?php get_header(); ?>
   <div class="hero">
    <img src="<?php echo get_template_directory_uri(); ?>/images/top.png" alt="top" class="top_pc" />
    <h2 class="page-title">H2タイトルが入ります</h2>
    <img src="<?php echo get_template_directory_uri(); ?>/images/sp/top.png" alt="top" class="top_sp" />
  </div>
  <div class="section breadcrumb-section">
    <ul class="breadcrumb">
      <li><a href="/">TOP</a></li>
      <li>bread</li>
    </ul>
  </div>
  <div class="section">
    <h3 class="page-main-title">H3タイトルが入ります</h3>
    <div class="line-horizontal"></div>
    <div class="paragraph-text">こちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入ります</div>
  </div>
  <div class="section">
    <h4 class="page-title">H4タイトルが入ります</h4>
    <div class="paragraph-content">
      <img src="<?php echo get_template_directory_uri(); ?>/images/under.png" alt="main" class="post_img_ad_set left">
      <div>回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト</div>
    </div>
  </div>
  <div class="section">
    <a href="#" class="text-banner">テギストバナー<i class="fas fa-chevron-right"></i></a>
  </div>
  <div class="section">
  <div class="bg-gray">
    <div class="section">
      <div class="page-sub-title">囲みデザイン</div>
      <div class="paragraph-text">こちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入りますこちらに本文テキストが入ります</div>
    </div>
  </div>
  </div>
  <div class="section list">
    <div class="page-sub-title">リスト</div>
    <ul>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
    </ul>
  </div>
  <div class="section number-list">
    <div class="page-sub-title">番号付きリスト</div>
    <ol start="1">
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
      <li>テキストが入りますテキストが入ります</li>
    </ol>
  </div>

  <div class="section">
    <div class="page-sub-title">テーブル</div>
    <div class="content-table-wrapper">
      <table class="content-table">
        <tbody>
          <tr>
            <td class="content-table-title-cell">テキストが入りますテキストが入ります</td>
          </tr>
          <tr>
            <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
          </tr>
          <tr>
            <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
          </tr>
          <tr>
            <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
          </tr>
        </tbody>
      </table>
      <table class="content-table">
        <tbody>
        <tr>
          <td class="content-table-title-cell">テキストが入りますテキストが入ります</td>
        </tr>
        <tr>
          <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
        </tr>
        <tr>
          <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
        </tr>
        <tr>
          <td class="content-table-content-cell">テキストが入りますテキストが入ります</td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="section">
    <h4 class="page-sub-title">フロー</h4>

      <div class="bg-gray flow-section">
        <div class="inside-section">
        <h4 class="page-title">H4タイトルが入ります</h4>
        <div class="paragraph-text">回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト</div>
      </div>
      </div>

    <div class="flow-arrow"></div>
    <div class="bg-gray flow-section">
      <div class="inside-section">
        <h4 class="page-title">H4タイトルが入ります</h4>
        <div class="paragraph-text">回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト</div>
      </div>
    </div>
    <div class="flow-arrow"></div>
    <div class="bg-gray flow-section">
      <div class="inside-section">
        <h4 class="page-title">H4タイトルが入ります</h4>
        <div class="paragraph-text">回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト回り込みテキスト</div>
      </div>
    </div>
  </div>
    <?php get_footer(); ?>
