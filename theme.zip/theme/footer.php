</main>
    <footer>
        <div class="footer-contact-box">
            <div class="footer-contact-box-inner footer-flex">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="logo" class="logo"/>
                <div class="contact-box">
                    <a href="" class="pc"><i class="fas fa-phone"></i>03-1234-5678</a>
                    <a href="" class="text-banner sp"><i class="fas fa-phone"></i>お電話はこちら<i
                            class="fas fa-chevron-right"></i></a>
                    <a href="/contact.php" class="text-banner"><i class="fas fa-envelope"></i>WEBお問い合わせ<i
                            class="fas fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-under-contents">
            <div class="footer-under-contents-inner footer-flex">
                <div class="contact-button">
                    <div class="contact-button-inner">
                        <a href="#">SITE MAP <i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
                <p>©︎銀座たるみクリニック</p>
            </div>
        </div>
        <div class="sp-float-contents">
            <div class="sp-float-contact">
                <span class="qa-content-title-tel"><i class="fas fa-phone"></i></span>
                <span class="qa-content-title-mail"><i class="fas fa-envelope"></i></span>
            </div>
            <div class="sp-float-too">
                <div class="qa-content-title-top">
                    <a href="#">
                        <p><i class="fas fa-chevron-up" aria-hidden="true"></i><br>
                            TOP</p>
                    </a>
                </div>
            </div>
        </div>
    </footer>
</div>
<?php wp_footer();?>
</body>
</html>
